Imports System.Runtime.InteropServices
Imports System.IO
Imports System.IO.Ports
Imports System.Windows.Forms
Imports System.Math

<ComVisible(False)>
Public Class Form1
    Const version As String = "V0.210720"
    Dim settingsPath As String = ""
    Dim settingsFile As String = "settings.ini"
    Dim commsError As Boolean = False
    Dim commsErrorMsg As Boolean = True
    Dim respStr As String = True
    ReadOnly resp(20) As String
    Dim comPort As String = ""
    ReadOnly getSettingsFlag As Boolean
    Dim canUpdate As Boolean = False
    Dim notMoving As Boolean = True

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        settingsPath = My.Computer.FileSystem.SpecialDirectories.MyDocuments + "\FocusBuddy"
        settingsFile = settingsPath + "\" + settingsFile
        lblVersion.Text = version
        GetSettings()
        btnUpdate.Enabled = False
        btnSync.Enabled = False
        btnReFormat.Enabled = True
        ComboBoxComPort.Items.Clear()
        ComboBoxComPort.Items.AddRange(SerialPort.GetPortNames())
        Dim listLength As Integer = ComboBoxComPort.Items.Count - 1
        Dim list(listLength) As Integer
        For i = 0 To listLength
            list(i) = Str(Mid(ComboBoxComPort.Items(i), 4, 3))
        Next
        Array.Sort(list)
        ComboBoxComPort.Items.Clear()
        For i = 0 To listLength
            ComboBoxComPort.Items.Add("COM" + list(i).ToString)
        Next
        If ComboBoxComPort.Items.Contains(comPort) Then
            ComboBoxComPort.SelectedItem = comPort
        End If
        If ComboBoxComPort.SelectedIndex > 0 Then lblStatus.Text = "Ready to attempt connection..."
        If chkConnectOnStartUp.Checked Then Retrieve()
        cbxMoves.Items.Add("User defined")
        cbxMoves.Items.Add("100")
        cbxMoves.Items.Add("200")
        cbxMoves.Items.Add("500")
        cbxMoves.Items.Add("1000")
        cbxMoves.Items.Add("2000")
        cbxMoves.Items.Add("5000")
        cbxMoves.SelectedIndex = 0
    End Sub

    Private Sub BtnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        'If MsgBox("Are you sure you want to leave?", vbYesNo, "FocusBuddy") = vbNo Then Exit Sub
        Timer1.Stop()
        Arduino(respStr, "Q")
        Close()
    End Sub
    Private Sub Retrieve()
        If ComboBoxComPort.SelectedIndex = -1 Then
            MsgBox("Please select COM port for FocusBuddy controller",, "FocusBuddy")
            Exit Sub
        End If

        lblRetrieve.Visible = True
        Dim i As Integer
        commsError = False
        commsErrorMsg = True
        If Arduino(respStr, "Q") Then Exit Sub
        Arduino(respStr, "R")                                           ' Reset Adruino and it's clock
        lblStatus.Text = ""
        For i = 1 To 10
            If i = 10 Then Exit Sub
            System.Threading.Thread.Sleep(100)
            commsError = False
            If Not Arduino(respStr, "V") Then Exit For
            commsErrorMsg = False
        Next

        commsErrorMsg = True
        If respStr.Contains("FocusBuddy") And commsError = False Then
            respStr = Mid(respStr, InStr(respStr, "FocusBuddy"), 64)
            lblStatus.Text = respStr + ".  FocusBuddy is responding."
        Else
            commsError = True
            lblRetrieve.Visible = False
            lblStatus.Text = "Ready to attempt connection..."
            Exit Sub
        End If

        For i = 0 To 9
            If Arduino(resp(i), "E" + i.ToString) Then Exit Sub
            If Arduino(resp(i + 10), "N" + i.ToString) Then Exit Sub
        Next
        If Arduino(resp(20), "P") Then Exit Sub
        lblRetrieve.Visible = False

        If commsError Then Return
        btnUpdate.Enabled = False
        nudPreset9.Value = CDec(resp(9))
        nudPreset0.Value = CDec(resp(0))
        nudPreset1.Value = CDec(resp(1))
        nudPreset2.Value = CDec(resp(2))
        nudPreset3.Value = CDec(resp(3))
        nudPreset4.Value = CDec(resp(4))
        nudPreset5.Value = CDec(resp(5))
        nudPreset6.Value = CDec(resp(6))
        nudPreset7.Value = CDec(resp(7))
        nudPreset8.Value = CDec(resp(8))
        txtName0.Text = resp(10)
        txtName1.Text = resp(11)
        txtName2.Text = resp(12)
        txtName3.Text = resp(13)
        txtName4.Text = resp(14)
        txtName5.Text = resp(15)
        txtName6.Text = resp(16)
        txtName7.Text = resp(17)
        txtName8.Text = resp(18)
        txtName9.Text = resp(19)
        If resp(20) < 1 Then resp(20) = 1
        If resp(20) > nudPreset9.Maximum Then resp(20) = nudPreset9.Maximum
        If Arduino(respStr, "p" + resp(20).ToString) Then Exit Sub
        txtCurrPos.Text = resp(20)
        nudTarget.Value = CDec(resp(20))
        radTarget.Checked = True
        Timer1.Interval = 1000
        btnUpdate.Enabled = False
        ServiceTimer()
    End Sub

    Private Function Arduino(ByRef resp As String, cmdStr As String) As Boolean
        resp = ""
        If commsError Then Return commsError

        Dim objSerial As New System.IO.Ports.SerialPort
        If ComboBoxComPort.SelectedIndex = -1 Then
            commsError = True
            Return commsError
        End If
        Try
            Dim comPort = ComboBoxComPort.SelectedItem.ToString
            With objSerial
                .PortName = ComboBoxComPort.SelectedItem.ToString
                .BaudRate = 9600
                .ReadTimeout = 1000
                .WriteTimeout = 1000
                .Open()
                .Write(cmdStr & vbLf)
            End With
            If cmdStr <> "R" Then resp = objSerial.ReadTo(vbCrLf)
        Catch ex As Exception
            resp = ""
            commsError = True
            If commsErrorMsg Then MsgBox("FocusBuddy is not responding!" + vbCrLf + vbCrLf + "Check COM port settings, connections, cabling and power.", vbCritical, "FocusBuddy")
            lblStatus.Text = "Ready to attempt connection..."
            lblMoving.Visible = False
            lblBacklash.Visible = False
            lblUpdating.Visible = False
            grpFocuserPresets.Enabled = False
            btnUpdate.Enabled = False
        End Try

        Try
            objSerial.Close()
        Catch ex As Exception
        End Try

        Return commsError
    End Function

    Private Sub BtnInitialise_Click(sender As Object, e As EventArgs) Handles btnInitialise.Click
        Retrieve()
    End Sub

    Private Sub BtnSync_Click(sender As Object, e As EventArgs) Handles btnSync.Click
        If MsgBox("Sync Current Postion to selection?", vbYesNo, "FocusBuddy") = vbNo Then Exit Sub
        If Arduino(respStr, "p" + GetPreset()) Then Exit Sub
        If Arduino(respStr, "P") Then Exit Sub
        Dim currPos As Decimal = Val(respStr)
        If currPos > nudPreset9.Maximum Then currPos = nudPreset9.Maximum
        If currPos < 1 Then currPos = 1
        txtCurrPos.Text = currPos.ToString
        nudCurrPos.Value = currPos
    End Sub

    Private Sub BtnGoto_Click(sender As Object, e As EventArgs) Handles btnGoto.Click
        Dim target As String = GetPreset()
        DoMove(IIf(CInt(target) < CInt(txtCurrPos.Text), "I", "O"), "g" + target)
    End Sub

    Private Sub BtnPulseOut_MouseDown(sender As Object, e As MouseEventArgs) Handles btnPulseOut.MouseDown
        If lblMoving.Visible Then Exit Sub
        DoMove("O", "O")
    End Sub

    Private Sub BtnPulseOut_MouseUp(sender As Object, e As MouseEventArgs) Handles btnPulseOut.MouseUp
        StopFocuser()
    End Sub

    Private Sub BtnPulseIn_MouseDown(sender As Object, e As MouseEventArgs) Handles btnPulseIn.MouseDown
        If lblMoving.Visible Then Exit Sub
        DoMove("I", "I")
    End Sub

    Private Sub BtnPulseIn_MouseUp(sender As Object, e As MouseEventArgs) Handles btnPulseIn.MouseUp
        StopFocuser()
    End Sub
    Private Sub BtnMoveFullyOut_Click(sender As Object, e As EventArgs) Handles btnMoveFullyOut.Click
        DoMove("O", "O")
    End Sub

    Private Sub BtnMoveFullyIn_Click(sender As Object, e As EventArgs) Handles btnMoveFullyIn.Click
        DoMove("I", "I")
    End Sub

    Private Sub BtnMoveOut_Click(sender As Object, e As EventArgs) Handles btnMoveOut.Click
        Dim dist As String = cbxMoves.SelectedItem.ToString
        If dist.StartsWith("User") Then dist = nudMove.Value.ToString
        DoMove("O", "O" + dist)
    End Sub

    Private Sub BtnMoveIn_Click(sender As Object, e As EventArgs) Handles btnMoveIn.Click
        Dim dist As String = cbxMoves.SelectedItem.ToString
        If dist.StartsWith("User") Then dist = nudMove.Value.ToString
        DoMove("I", "I" + dist)
    End Sub

    Private Sub BtnStop_Click(sender As Object, e As EventArgs) Handles btnStop.Click
        StopFocuser()
    End Sub

    Private Sub StopFocuser()
        Arduino(respStr, "Q")
        ServiceTimer()
    End Sub

    Private Sub DoMove(targDir As String, moveCmd As String)
        txtLastMove.Text = IIf(targDir = "I", "In", "Out")
        If Arduino(respStr, "L") Then Exit Sub
        If Not radBacklashDisabled.Checked AndAlso targDir <> respStr Then
            ' Deal with backlash
            Dim backlashCmd As String = ""
            If targDir = "O" Then If radOutward.Checked Or radBothWays.Checked Then backlashCmd = "O"
            If targDir = "I" Then If radInward.Checked Or radBothWays.Checked Then backlashCmd = "I"
            If backlashCmd <> "" Then                               ' Act if necessary
                lblBacklash.Visible = True                          ' Display "BACKLASH"
                Arduino(respStr, "P")
                Dim oldPos As String = respStr                      ' Remember current position
                If Arduino(respStr, backlashCmd + nudBacklash.Value.ToString) Then Exit Sub ' Soak up the backlash
                Threading.Thread.Sleep(CInt(nudBacklash.Value))     ' Wait for backlash period
                Do
                    If Arduino(respStr, "M") Then Exit Sub
                Loop While respStr = "1"                             ' Wait for the focuser to stop moving
                Arduino(respStr, "p" + oldPos)
                lblBacklash.Visible = False                          ' Hide "BACKLASH"
            End If
            ' Backlash dealt with
        End If
        txtLastMove.Text = IIf(targDir = "I", "In", "Out")
        'moveCmd = moveCmd.ToLower()
        If Arduino(respStr, moveCmd) Then Exit Sub
        ServiceTimer()
    End Sub

    Private Sub BtnUpdate_Click(sender As Object, e As EventArgs) Handles btnUpdate.Click
        If btnUpdate.Enabled = False Then Exit Sub
        If notMoving = False Then Exit Sub
        lblUpdating.Visible = True
        If CDec(resp(0)) <> nudPreset0.Value Then If Arduino(respStr, "z" + CStr(nudPreset0.Value) + "e0") Then Exit Sub
        If CDec(resp(1)) <> nudPreset1.Value Then If Arduino(respStr, "z" + CStr(nudPreset1.Value) + "e1") Then Exit Sub
        If CDec(resp(2)) <> nudPreset2.Value Then If Arduino(respStr, "z" + CStr(nudPreset2.Value) + "e2") Then Exit Sub
        If CDec(resp(3)) <> nudPreset3.Value Then If Arduino(respStr, "z" + CStr(nudPreset3.Value) + "e3") Then Exit Sub
        If CDec(resp(4)) <> nudPreset4.Value Then If Arduino(respStr, "z" + CStr(nudPreset4.Value) + "e4") Then Exit Sub
        If CDec(resp(5)) <> nudPreset5.Value Then If Arduino(respStr, "z" + CStr(nudPreset5.Value) + "e5") Then Exit Sub
        If CDec(resp(6)) <> nudPreset6.Value Then If Arduino(respStr, "z" + CStr(nudPreset6.Value) + "e6") Then Exit Sub
        If CDec(resp(7)) <> nudPreset7.Value Then If Arduino(respStr, "z" + CStr(nudPreset7.Value) + "e7") Then Exit Sub
        If CDec(resp(8)) <> nudPreset8.Value Then If Arduino(respStr, "z" + CStr(nudPreset8.Value) + "e8") Then Exit Sub
        If CDec(resp(9)) <> nudPreset9.Value Then If Arduino(respStr, "z" + CStr(nudPreset9.Value) + "e9") Then Exit Sub
        If CDec(resp(20)) <> nudCurrPos.Value Then If Arduino(respStr, "p" + CStr(nudCurrPos.Value)) Then Exit Sub
        If resp(11) <> txtName1.Text Then If Arduino(respStr, "n1" + txtName1.Text + "#") Then Exit Sub
        If resp(12) <> txtName2.Text Then If Arduino(respStr, "n2" + txtName2.Text + "#") Then Exit Sub
        If resp(13) <> txtName3.Text Then If Arduino(respStr, "n3" + txtName3.Text + "#") Then Exit Sub
        If resp(14) <> txtName4.Text Then If Arduino(respStr, "n4" + txtName4.Text + "#") Then Exit Sub
        If resp(15) <> txtName5.Text Then If Arduino(respStr, "n5" + txtName5.Text + "#") Then Exit Sub
        If resp(16) <> txtName6.Text Then If Arduino(respStr, "n6" + txtName6.Text + "#") Then Exit Sub
        If resp(17) <> txtName7.Text Then If Arduino(respStr, "n7" + txtName7.Text + "#") Then Exit Sub
        If resp(18) <> txtName8.Text Then If Arduino(respStr, "n8" + txtName8.Text + "#") Then Exit Sub
        If Arduino(respStr, "p" + nudCurrPos.Value.ToString) Then Exit Sub
        txtCurrPos.Text = nudCurrPos.Value.ToString
        btnUpdate.Enabled = False
        lblUpdating.Visible = False
    End Sub

    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick
        ServiceTimer()
    End Sub

    Sub ServiceTimer()
        Dim currPos As Decimal
        'Me.TopMost = False
        Arduino(respStr, "M")
        If respStr <> "1" Then
            Timer1.Stop()
            lblMoving.Visible = False
            notMoving = True
            btnInitialise.Enabled = True
            btnSync.Enabled = True
            btnReFormat.Enabled = True
            ComboBoxComPort.Enabled = True
            grpFocuserPresets.Enabled = True
            grpBacklash.Enabled = True
            chkRevDir.Enabled = True
            nudCurrPos.Enabled = True
            nudCurrPos.Value = CDec(txtCurrPos.Text)
            If Arduino(respStr, "L") Then
                txtLastMove.Text = "---"
                txtCurrPos.Text = "------"
                Exit Sub
            End If
            txtLastMove.Text = IIf(respStr = "I", "In", "Out")
        ElseIf notMoving Then
            lblMoving.Visible = True
            Timer1.Interval = 1000
            Timer1.Start()
            btnInitialise.Enabled = False
            btnSync.Enabled = False
            btnReFormat.Enabled = False
            ComboBoxComPort.Enabled = True
            grpBacklash.Enabled = False
            chkRevDir.Enabled = False
            nudCurrPos.Enabled = False
            notMoving = False
        End If

        If Arduino(respStr, "P") Then
            txtLastMove.Text = "---"
            txtCurrPos.Text = "------"
            Exit Sub
        End If
        currPos = Val(respStr)
        If currPos > nudPreset9.Maximum Then currPos = nudPreset9.Maximum
        If currPos < 1 Then currPos = 1
        txtCurrPos.Text = currPos.ToString
    End Sub

    Private Function GetPreset() As String
        Dim preset As Decimal = nudCurrPos.Value
        If radTarget.Checked Then preset = nudTarget.Value
        If radPreset0.Checked Then preset = nudPreset0.Value
        If radPreset1.Checked Then preset = nudPreset1.Value
        If radPreset2.Checked Then preset = nudPreset2.Value
        If radPreset3.Checked Then preset = nudPreset3.Value
        If radPreset4.Checked Then preset = nudPreset4.Value
        If radPreset5.Checked Then preset = nudPreset5.Value
        If radPreset6.Checked Then preset = nudPreset6.Value
        If radPreset7.Checked Then preset = nudPreset7.Value
        If radPreset8.Checked Then preset = nudPreset8.Value
        If radPreset9.Checked Then preset = nudPreset9.Value
        If preset < 1 Then preset = 1
        If preset > nudPreset9.Value Then preset = nudPreset9.Value
        Return preset
    End Function

    Private Sub TxtName1_TextChanged(sender As Object, e As EventArgs) Handles txtName1.TextChanged
        If notMoving Then btnUpdate.Enabled = True
    End Sub

    Private Sub TxtName2_TextChanged(sender As Object, e As EventArgs) Handles txtName2.TextChanged
        btnUpdate.Enabled = True
    End Sub

    Private Sub TxtName3_TextChanged(sender As Object, e As EventArgs) Handles txtName3.TextChanged
        btnUpdate.Enabled = True
    End Sub

    Private Sub TxtName4_TextChanged(sender As Object, e As EventArgs) Handles txtName4.TextChanged
        btnUpdate.Enabled = True
    End Sub

    Private Sub TxtName5_TextChanged(sender As Object, e As EventArgs) Handles txtName5.TextChanged
        btnUpdate.Enabled = True
    End Sub

    Private Sub TxtName6_TextChanged(sender As Object, e As EventArgs) Handles txtName6.TextChanged
        btnUpdate.Enabled = True
    End Sub

    Private Sub TxtName7_TextChanged(sender As Object, e As EventArgs) Handles txtName7.TextChanged
        btnUpdate.Enabled = True
    End Sub

    Private Sub TxtName8_TextChanged(sender As Object, e As EventArgs) Handles txtName8.TextChanged
        btnUpdate.Enabled = True
    End Sub

    Private Sub NudCurrPos_ValueChanged(sender As Object, e As EventArgs) Handles nudCurrPos.ValueChanged
        If lblMoving.Visible = False Then btnUpdate.Enabled = True
    End Sub

    Private Sub NudPreset0_ValueChanged(sender As Object, e As EventArgs) Handles nudPreset0.ValueChanged
        btnUpdate.Enabled = True
    End Sub

    Private Sub NudPreset1_ValueChanged(sender As Object, e As EventArgs) Handles nudPreset1.ValueChanged
        btnUpdate.Enabled = True
    End Sub

    Private Sub NudPreset2_ValueChanged(sender As Object, e As EventArgs) Handles nudPreset2.ValueChanged
        btnUpdate.Enabled = True
    End Sub

    Private Sub NudPreset3_ValueChanged(sender As Object, e As EventArgs) Handles nudPreset3.ValueChanged
        btnUpdate.Enabled = True
    End Sub

    Private Sub NudPreset4_ValueChanged(sender As Object, e As EventArgs) Handles nudPreset4.ValueChanged
        btnUpdate.Enabled = True
    End Sub

    Private Sub NudPreset5_ValueChanged(sender As Object, e As EventArgs) Handles nudPreset5.ValueChanged
        btnUpdate.Enabled = True
    End Sub

    Private Sub NudPreset6_ValueChanged(sender As Object, e As EventArgs) Handles nudPreset6.ValueChanged
        btnUpdate.Enabled = True
    End Sub

    Private Sub NudPreset7_ValueChanged(sender As Object, e As EventArgs) Handles nudPreset7.ValueChanged
        btnUpdate.Enabled = True
    End Sub

    Private Sub NudPreset8_ValueChanged(sender As Object, e As EventArgs) Handles nudPreset8.ValueChanged
        btnUpdate.Enabled = True
    End Sub

    Private Sub NudPreset9_ValueChanged(sender As Object, e As EventArgs) Handles nudPreset9.ValueChanged
        btnUpdate.Enabled = True
    End Sub

    Private Sub ComboBoxComPort_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ComboBoxComPort.SelectedIndexChanged
        comPort = ComboBoxComPort.SelectedItem
        lblStatus.Text = "Ready to attempt connection..."
        WriteSettingsFile()
    End Sub

    Private Sub ChkConnectOnStartUp_CheckedChanged(sender As Object, e As EventArgs) Handles chkConnectOnStartUp.CheckedChanged
        WriteSettingsFile()
    End Sub

    Private Sub RadBacklashDisabled_CheckedChanged(sender As Object, e As EventArgs) Handles radBacklashDisabled.CheckedChanged
        WriteSettingsFile()
    End Sub

    Private Sub RadOutward_CheckedChanged(sender As Object, e As EventArgs) Handles radOutward.CheckedChanged
        WriteSettingsFile()
    End Sub

    Private Sub RadInward_CheckedChanged(sender As Object, e As EventArgs) Handles radInward.CheckedChanged
        WriteSettingsFile()
    End Sub

    Private Sub NudBacklash_ValueChanged(sender As Object, e As EventArgs) Handles nudBacklash.ValueChanged
        WriteSettingsFile()
    End Sub

    Private Sub NudMove_ValueChanged(sender As Object, e As EventArgs) Handles nudMove.ValueChanged
        WriteSettingsFile()
    End Sub

    Private Sub GetSettings()
        Dim line As String
        Dim valStr As String
        Dim errorFlag As Boolean

        Do
            canUpdate = False
            If File.Exists(settingsFile) = False Then
                chkConnectOnStartUp.Checked = False
                radBacklashDisabled.Checked = True
                radInward.Checked = False
                radOutward.Checked = False
                nudBacklash.Value = 1000
                WriteSettingsFile()
                canUpdate = True
                Exit Sub
            End If

            chkConnectOnStartUp.Checked = False
            radBacklashDisabled.Checked = True
            nudBacklash.Value = 1000

            errorFlag = False
            FileOpen(1, settingsFile, OpenMode.Input)
            While EOF(1) = False
                line = LineInput(1)
                valStr = Trim(Mid(line, InStr(line, "=") + 1, 256))
                Select Case Trim(Strings.Left(line, InStr(line, "=") - 1))
                    Case "COMPort"
                        comPort = valStr
                    Case "ConnectOnStartUp"
                        If valStr = "True" Then chkConnectOnStartUp.Checked = True
                    Case "BacklashMode"
                        If valStr = "Inwards" Then radInward.Checked = True
                        If valStr = "Outwards" Then radInward.Checked = True
                        If valStr = "BothWays" Then radBothWays.Checked = True
                    Case "BacklashAllowance"
                        If CInt(valStr) >= 0 And CInt(valStr) <= 10000 Then nudBacklash.Value = Val(valStr)
                    Case "UserMoveAmount"
                        If CInt(valStr) >= 0 And CInt(valStr) <= nudPreset9.Value Then nudMove.Value = Val(valStr)
                    Case Else
                        errorFlag = True    ' settings.ini is not in correct format
                End Select
            End While
            FileClose(1)
            If errorFlag Then File.Delete(settingsFile)
        Loop While errorFlag
        canUpdate = True
    End Sub

    Private Sub WriteSettingsFile()
        If canUpdate = False Then Exit Sub
        If Not My.Computer.FileSystem.DirectoryExists(settingsPath) Then My.Computer.FileSystem.CreateDirectory(settingsPath)
        File.Delete(settingsFile)
        Using sw As New StreamWriter(settingsFile)
            sw.WriteLine("COMPort           = " + comPort)
            sw.WriteLine("ConnectOnStartUp  = " + chkConnectOnStartUp.Checked.ToString)
            If radBacklashDisabled.Checked = True Then sw.WriteLine("BacklashMode      = Disabled")
            If radInward.Checked = True Then sw.WriteLine("BacklashMode      = Inwards")
            If radOutward.Checked = True Then sw.WriteLine("BacklashMode      = Outwards")
            If radBothWays.Checked = True Then sw.WriteLine("BacklashMode      = BothWays")
            sw.WriteLine("BacklashAllowance = " + nudBacklash.Value.ToString)
            sw.WriteLine("UserMoveAmount    = " + nudMove.Value.ToString)
        End Using
    End Sub

    Private Sub ChkRevDir_CheckedChanged(sender As Object, e As EventArgs) Handles chkRevDir.CheckedChanged
        If chkRevDir.Checked Then If Arduino(respStr, "<") Then Exit Sub
        If Not chkRevDir.Checked Then If Arduino(respStr, ">") Then Exit Sub
    End Sub

    Private Sub btnReFormat_Click(sender As Object, e As EventArgs) Handles btnReFormat.Click
        If ComboBoxComPort.SelectedIndex = -1 Then
            MsgBox("Please select COM port for FocusBuddy controller",, "FocusBuddy")
            Exit Sub
        End If
        commsError = False
        commsErrorMsg = True
        If Arduino(respStr, "Q") Then Exit Sub

        If MsgBox("Reformat EEPROM - are sure?", vbYesNo, "FocusBuddy") = vbNo Then Exit Sub
        If MsgBox("Do you want to change you mind?", vbYesNo, "FocusBuddy") = vbYes Then Exit Sub
        If MsgBox("Click OK to reformat the EEPROM.", vbOKCancel, "FocusBuddy") = vbCancel Then Exit Sub
        commsErrorMsg = False
        Arduino(respStr, "W")
        Arduino(respStr, "F")
        Arduino(respStr, "R")
        commsErrorMsg = True
        MsgBox("EEPROM has been reformatted", vbOK, "FocusBuddy")
        Retrieve()
    End Sub

    Private Sub GitHubLogo_Click(sender As Object, e As EventArgs) Handles GitHubLogo.Click
        Dim Browser As New Process
        Browser.StartInfo.FileName = "https://github.com/kickitharder/FocusBuddy"
        Browser.StartInfo.UseShellExecute = True
        Browser.StartInfo.RedirectStandardOutput = False
        Try
            Browser.Start()
        Catch ex As Exception

        End Try
        Browser.Dispose()
    End Sub

    Private Sub CMHASDLogo_Click(sender As Object, e As EventArgs) Handles CMHASDLogo.Click
        Dim Browser As New Process
        Browser.StartInfo.FileName = "https://crayfordmanorastro.com/"
        Browser.StartInfo.UseShellExecute = True
        Browser.StartInfo.RedirectStandardOutput = False
        Try
            Browser.Start()
        Catch ex As Exception

        End Try
        Browser.Dispose()
    End Sub
End Class
